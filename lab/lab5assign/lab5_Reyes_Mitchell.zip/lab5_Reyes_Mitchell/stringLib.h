
void stringCopy(char *s1, char *s2);
void stringCat(char *s1, char *s2);
void stringLen(char *s1, char *s2);
void stringComp(char *s1, char *s2);
