
void stringCopy(char *dest, char *src);
void stringCat(char *s1, char *s2);
int stringLen(char *s1);
void stringComp(char *s1, char *s2);
