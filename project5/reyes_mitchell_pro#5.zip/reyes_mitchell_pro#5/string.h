void stringCopy(char *dest, char *src);
int stringLen(char *word);