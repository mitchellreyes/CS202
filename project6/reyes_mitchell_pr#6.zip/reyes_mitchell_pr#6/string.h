//this is where the string function prototypes go
void stringCopy(char *dest, char* src);
bool stringComp(char *string1, char *string2);
int stringLength(char *string1);